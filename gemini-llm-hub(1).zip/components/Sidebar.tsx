
import React from 'react';
import { View } from '../types';
import Icon from './Icon';

interface SidebarProps {
  activeView: View;
  setActiveView: (view: View) => void;
  isSidebarOpen: boolean;
}

const sidebarItems: { id: View; name: string }[] = [
  { id: 'chat', name: 'Chat' },
  { id: 'text', name: 'Text Gen' },
  { id: 'code', name: 'Code Gen' },
  { id: 'image', name: 'Image Gen' },
];

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, isSidebarOpen }) => {
  return (
    <aside
      className={`absolute inset-y-0 left-0 bg-white dark:bg-gray-900/70 backdrop-blur-lg z-30 transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0 ${
        isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } w-64 border-r border-gray-200 dark:border-gray-700 flex flex-col`}
    >
      <div className="flex items-center justify-center h-20 border-b border-gray-200 dark:border-gray-700 px-4">
        <Icon name="gemini" className="w-8 h-8 text-blue-500" />
        <h1 className="text-xl font-bold ml-3 text-gray-800 dark:text-gray-100">LLM Hub</h1>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {sidebarItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            className={`w-full flex items-center p-3 rounded-lg transition-colors duration-200 ${
              activeView === item.id
                ? 'bg-blue-500 text-white'
                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <Icon name={item.id} className="w-6 h-6 mr-4" />
            <span className="font-medium">{item.name}</span>
          </button>
        ))}
      </nav>
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 text-center">
        <p className="text-xs text-gray-500 dark:text-gray-400">Powered by Google Gemini</p>
      </div>
    </aside>
  );
};

export default Sidebar;
