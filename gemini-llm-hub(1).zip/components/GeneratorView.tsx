
import React, { useState, useCallback } from 'react';
import LoadingSpinner from './LoadingSpinner';
import { View, GeminiModel } from '../types';

interface GeneratorViewProps {
  type: Exclude<View, 'chat'>;
  title: string;
  description: string;
  placeholder: string;
  generateFunction: (prompt: string, model: GeminiModel) => Promise<string>;
}

const GeneratorView: React.FC<GeneratorViewProps> = ({ type, title, description, placeholder, generateFunction }) => {
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [selectedModel, setSelectedModel] = useState<GeminiModel>(type === 'code' ? 'gemini-2.5-pro' : 'gemini-2.5-flash');

  const handleGenerate = useCallback(async () => {
    if (!prompt.trim()) return;
    setIsLoading(true);
    setResult('');
    setError(null);
    try {
      const response = await generateFunction(prompt, selectedModel);
      if (type === 'image' && response === 'error') {
          setError('Could not generate image. The prompt may have been blocked.');
      } else {
          setResult(response);
      }
    } catch (e) {
        setError('An unexpected error occurred. Please check the console.');
        console.error(e);
    } finally {
        setIsLoading(false);
    }
  }, [prompt, generateFunction, type, selectedModel]);
  
  const handleCopy = useCallback(() => {
    if (!result) return;
    const codeToCopy = result.replace(/```(html|css|js|jsx|ts|tsx|python|java)?/g, '').replace(/```/g, '').trim();
    navigator.clipboard.writeText(codeToCopy).then(() => {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
    }).catch(err => {
        console.error('Failed to copy code: ', err);
    });
  }, [result]);

  const ResultDisplay = () => {
    if (isLoading) {
        return <div className="flex justify-center items-center h-64"><LoadingSpinner size="lg" /></div>;
    }
    if (error) {
        return <div className="p-4 bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300 rounded-lg">{error}</div>
    }
    if (!result) {
        return <div className="text-center text-gray-500 dark:text-gray-400">Your generated content will appear here.</div>;
    }

    switch (type) {
        case 'image':
            return <img src={result} alt={prompt} className="rounded-lg shadow-lg mx-auto max-w-full h-auto" />;
        case 'code':
            return (
                <div className="relative group">
                    <button 
                        onClick={handleCopy}
                        className="absolute top-3 right-3 px-3 py-1 bg-gray-700 hover:bg-gray-600 text-white text-xs font-semibold rounded-md opacity-0 group-hover:opacity-100 transition-all duration-200 z-10"
                        aria-label="Copy code to clipboard"
                    >
                        {isCopied ? (
                            <span className="flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                </svg>
                                Copied!
                            </span>
                        ) : (
                             <span className="flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                </svg>
                                Copy Code
                            </span>
                        )}
                    </button>
                    <pre className="bg-gray-900 text-white p-4 pt-10 rounded-lg overflow-x-auto font-mono text-sm"><code dangerouslySetInnerHTML={{ __html: result.replace(/```(html|css|js|jsx|ts|tsx|python|java)?/g, '').replace(/```/g, '') }} /></pre>
                </div>
            );
        case 'text':
            return <div className="prose dark:prose-invert max-w-none p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg" dangerouslySetInnerHTML={{ __html: result.replace(/\n/g, '<br/>') }}></div>;
        default:
            return null;
    }
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-800">
      <header className="p-4 border-b border-gray-200 dark:border-gray-700">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">{title}</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">{description}</p>
      </header>
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="flex-1 flex flex-col gap-4">
            <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={placeholder}
                className="w-full p-4 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none resize-none text-gray-800 dark:text-gray-200 text-base"
                rows={5}
                disabled={isLoading}
            />
            {(type === 'text' || type === 'code') && (
              <div className="space-y-2">
                <p className="font-medium text-gray-700 dark:text-gray-300 text-sm">Select Model</p>
                <div className="flex items-center gap-6">
                  <label htmlFor="flash-model" className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      id="flash-model"
                      name="model"
                      value="gemini-2.5-flash"
                      checked={selectedModel === 'gemini-2.5-flash'}
                      onChange={() => setSelectedModel('gemini-2.5-flash')}
                      className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                      Gemini 2.5 Flash <span className="text-xs text-gray-500">(Fast & Efficient)</span>
                    </span>
                  </label>
                  <label htmlFor="pro-model" className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      id="pro-model"
                      name="model"
                      value="gemini-2.5-pro"
                      checked={selectedModel === 'gemini-2.5-pro'}
                      onChange={() => setSelectedModel('gemini-2.5-pro')}
                      className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                      Gemini 2.5 Pro <span className="text-xs text-gray-500">(Advanced Reasoning)</span>
                    </span>
                  </label>
                </div>
              </div>
            )}
            <button
                onClick={handleGenerate}
                disabled={isLoading || !prompt.trim()}
                className="w-full sm:w-auto self-start px-6 py-3 rounded-lg bg-blue-500 text-white font-semibold disabled:bg-gray-400 disabled:dark:bg-gray-600 hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
            >
                {isLoading ? <><LoadingSpinner size="sm" /> Generating...</> : 'Generate'}
            </button>
        </div>
        <div className="mt-6 p-4 border-t border-gray-200 dark:border-gray-700 min-h-[200px]">
           <ResultDisplay />
        </div>
      </div>
    </div>
  );
};

export default GeneratorView;