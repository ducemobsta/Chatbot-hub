
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ChatMessage } from '../types';
import { createChatSession, streamChatResponse } from '../services/geminiService';
import type { Chat } from '@google/genai';
import LoadingSpinner from './LoadingSpinner';

const UserAvatar: React.FC = () => (
    <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center font-bold text-white">U</div>
);

const ModelAvatar: React.FC = () => (
    <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-white">
            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
        </svg>
    </div>
);

const ChatView: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatSession = useRef<Chat | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatSession.current = createChatSession();
    }, []);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSend = useCallback(async () => {
        if (!input.trim() || !chatSession.current || isLoading) return;

        const userMessage: ChatMessage = { role: 'user', parts: [{ text: input }] };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        // Add a placeholder for the model's response
        setMessages(prev => [...prev, { role: 'model', parts: [{ text: '' }] }]);

        try {
            const stream = await streamChatResponse(chatSession.current, input);
            let text = '';
            for await (const chunk of stream) {
                text += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { role: 'model', parts: [{ text }] };
                    return newMessages;
                });
            }
        } catch (error) {
            console.error(error);
            setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length-1] = { role: 'model', parts: [{ text: 'Sorry, something went wrong.' }] };
                return newMessages;
            });
        } finally {
            setIsLoading(false);
        }
    }, [input, isLoading]);

    return (
        <div className="flex flex-col h-full bg-white dark:bg-gray-800">
            <header className="p-4 border-b border-gray-200 dark:border-gray-700">
                <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Chat with Gemini</h2>
            </header>
            <main className="flex-1 overflow-y-auto p-6 space-y-6">
                {messages.length === 0 && !isLoading && (
                     <div className="text-center text-gray-500 dark:text-gray-400">Start a conversation!</div>
                )}
                {messages.map((msg, index) => (
                    <div key={index} className={`flex items-start gap-4 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                        {msg.role === 'model' && <ModelAvatar />}
                        <div className={`max-w-xl p-4 rounded-2xl ${
                            msg.role === 'user'
                                ? 'bg-blue-500 text-white rounded-br-none'
                                : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-bl-none'
                        }`}>
                           {msg.parts[0].text ? (
                             <div className="prose dark:prose-invert" dangerouslySetInnerHTML={{ __html: msg.parts[0].text.replace(/\n/g, '<br />') }} />
                           ) : (
                             <div className="flex items-center justify-center p-2"><LoadingSpinner size="sm" /></div>
                           )}
                        </div>
                        {msg.role === 'user' && <UserAvatar />}
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </main>
            <footer className="p-4 border-t border-gray-200 dark:border-gray-700">
                <div className="relative">
                    <textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSend();
                            }
                        }}
                        placeholder="Type your message..."
                        className="w-full p-4 pr-20 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none resize-none text-gray-800 dark:text-gray-200"
                        rows={1}
                        disabled={isLoading}
                    />
                    <button
                        onClick={handleSend}
                        disabled={isLoading || !input.trim()}
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-blue-500 text-white disabled:bg-gray-400 disabled:dark:bg-gray-600 hover:bg-blue-600 transition-colors"
                    >
                        {isLoading ? <LoadingSpinner size="sm" /> : 
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path d="M3.105 3.105a.75.75 0 01.056 1.053L5.435 8.25H15a.75.75 0 010 1.5H5.435l-2.274 4.092a.75.75 0 01-1.11-1.054l2.274-4.092a.75.75 0 010-1.054L2.001 4.158a.75.75 0 011.104-1.054z" /></svg>}
                    </button>
                </div>
            </footer>
        </div>
    );
};

export default ChatView;
