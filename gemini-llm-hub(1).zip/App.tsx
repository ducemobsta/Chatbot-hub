
import React, { useState } from 'react';
import { View } from './types';
import Sidebar from './components/Sidebar';
import ChatView from './components/ChatView';
import GeneratorView from './components/GeneratorView';
import { generateText, generateCode, generateImage } from './services/geminiService';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>('chat');
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const renderActiveView = () => {
    switch (activeView) {
      case 'chat':
        return <ChatView />;
      case 'text':
        return <GeneratorView 
                  type="text"
                  title="Text Generation"
                  description="Generate creative and informative text for any purpose."
                  placeholder="e.g., Write a short story about a robot who discovers music."
                  generateFunction={generateText}
                />;
      case 'code':
        return <GeneratorView 
                  type="code"
                  title="Code Generation"
                  description="Generate code snippets in various programming languages."
                  placeholder="e.g., Create a Python function to fetch data from an API."
                  generateFunction={generateCode}
                />;
      case 'image':
        return <GeneratorView
                  type="image"
                  title="Image Generation"
                  description="Create stunning visuals from your text descriptions."
                  placeholder="e.g., An astronaut riding a horse on Mars, cinematic lighting."
                  generateFunction={generateImage}
                />;
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen w-full bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      <Sidebar activeView={activeView} setActiveView={setActiveView} isSidebarOpen={isSidebarOpen} />
      
      {isSidebarOpen && (
          <div 
              onClick={() => setSidebarOpen(false)} 
              className="fixed inset-0 bg-black/30 z-20 md:hidden"
          ></div>
      )}

      <div className="flex-1 flex flex-col">
        <header className="md:hidden flex items-center justify-between p-4 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 text-blue-500">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                </svg>
                <h1 className="text-lg font-bold">LLM Hub</h1>
            </div>
            <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="p-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                </svg>
            </button>
        </header>

        <main className="flex-1 overflow-hidden">
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
};

export default App;
