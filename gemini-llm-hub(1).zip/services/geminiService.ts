
import { GoogleGenAI, Chat } from "@google/genai";
import { GeminiModel } from "../types";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const createChatSession = (): Chat => {
    return ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: 'You are a helpful and creative assistant. Be friendly and engaging.',
        },
    });
};

export const streamChatResponse = async (chat: Chat, prompt: string) => {
    return chat.sendMessageStream({ message: prompt });
};

export const generateText = async (prompt: string, model: GeminiModel): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating text:", error);
        return "Sorry, I couldn't generate a response. Please try again.";
    }
};

export const generateCode = async (prompt: string, model: GeminiModel): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
                systemInstruction: "You are a coding expert. Provide clean, efficient, and well-documented code in the requested language. Add explanations for complex parts. Use markdown for code blocks.",
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error generating code:", error);
        return "Sorry, I couldn't generate code. Please try again.";
    }
};

export const generateImage = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/png',
              aspectRatio: '1:1',
            },
        });
        
        const base64ImageBytes = response.generatedImages[0].image.imageBytes;
        return `data:image/png;base64,${base64ImageBytes}`;
    } catch (error) {
        console.error("Error generating image:", error);
        return "error";
    }
};