
export type View = 'chat' | 'text' | 'code' | 'image';

export type GeminiModel = 'gemini-2.5-flash' | 'gemini-2.5-pro';

export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}