"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export function WebSummarizer() {
  const [url, setUrl] = useState("")
  const [isSummarizing, setIsSummarizing] = useState(false)

  const handleSummarize = async () => {
    if (!url.trim()) return
    setIsSummarizing(true)
    // TODO: Implement web summarization API call
    setTimeout(() => {
      setIsSummarizing(false)
    }, 2000)
  }

  return (
    <div className="flex h-full items-start justify-center p-8">
      <Card className="w-full max-w-2xl p-8">
        <h1 className="mb-6 text-center text-2xl font-semibold">Webpage Summarizer</h1>

        <div className="flex gap-2">
          <Input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter the URL of the webpage to summarize"
            className="flex-1"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleSummarize()
              }
            }}
          />
          <Button
            onClick={handleSummarize}
            disabled={!url.trim() || isSummarizing}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isSummarizing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Summarizing...
              </>
            ) : (
              "Summarize"
            )}
          </Button>
        </div>
      </Card>
    </div>
  )
}
