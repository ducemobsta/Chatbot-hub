"use client"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { X, ChevronDown, Loader2, Copy, Edit, RotateCcw, Trash2, MoreVertical } from "lucide-react"
import { cn } from "@/lib/utils"
import type { ChatSession, Model } from "./multi-model-chat"
import { useEffect, useRef, useState } from "react"

type ChatPanelProps = {
  session: ChatSession
  availableModels: Model[]
  onRemove: () => void
  onChangeModel: (model: Model) => void
  onRetryMessage: (messageIndex: number) => void
  onEditMessage: (messageIndex: number, newContent: string) => void
  onDeleteMessage: (messageIndex: number) => void
}

export function ChatPanel({
  session,
  availableModels,
  onRemove,
  onChangeModel,
  onRetryMessage,
  onEditMessage,
  onDeleteMessage,
}: ChatPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [editingIndex, setEditingIndex] = useState<number | null>(null)
  const [editContent, setEditContent] = useState("")

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [session.messages])

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const handleEdit = (index: number, content: string) => {
    setEditingIndex(index)
    setEditContent(content)
  }

  const handleSaveEdit = (index: number) => {
    onEditMessage(index, editContent)
    setEditingIndex(null)
    setEditContent("")
  }

  return (
    <div className="flex flex-col overflow-hidden rounded-lg border bg-card">
      {/* Header */}
      <div className="flex items-center justify-between border-b px-4 py-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="gap-2">
              <span className="text-sm">{session.model.name}</span>
              <ChevronDown className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            {availableModels.map((model) => (
              <DropdownMenuItem key={model.id} onClick={() => onChangeModel(model)}>
                {model.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        <Button variant="ghost" size="icon" onClick={onRemove}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4">
        {session.messages.length === 0 ? (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            Start a conversation with {session.model.name}
          </div>
        ) : (
          <div className="space-y-4">
            {session.messages.map((message, index) => (
              <div
                key={index}
                className={cn(
                  "group relative rounded-lg p-3 text-sm",
                  message.role === "user"
                    ? "bg-primary text-primary-foreground ml-auto max-w-[85%]"
                    : "bg-muted mr-auto max-w-[85%]",
                )}
              >
                {editingIndex === index ? (
                  <div className="space-y-2">
                    <textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="w-full rounded border bg-background p-2 text-sm"
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => handleSaveEdit(index)}>
                        Save
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditingIndex(null)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>
                    <div className="absolute -top-2 right-2 hidden group-hover:flex gap-1">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="icon" variant="secondary" className="h-6 w-6 rounded-full shadow-sm">
                            <MoreVertical className="h-3 w-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleCopy(message.content)}>
                            <Copy className="mr-2 h-4 w-4" />
                            Copy
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEdit(index, message.content)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onRetryMessage(index)}>
                            <RotateCcw className="mr-2 h-4 w-4" />
                            Retry
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => onDeleteMessage(index)} className="text-destructive">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </>
                )}
              </div>
            ))}
            {session.isLoading && (
              <div className="flex items-center gap-2 rounded-lg bg-muted p-3 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>{session.model.name} is thinking...</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
