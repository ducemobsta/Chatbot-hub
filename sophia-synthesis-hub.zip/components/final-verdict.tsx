import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Shield } from "lucide-react"

interface FinalVerdictProps {
  query: string
}

export function FinalVerdict({ query }: FinalVerdictProps) {
  return (
    <Card className="border-success/30 bg-card/80 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-success" />
            <CardTitle className="font-mono text-primary">Sophia Final Verdict: Synthesized & Compliant</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-success text-success-foreground font-mono">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Consensus: 92.4%
            </Badge>
            <Badge className="bg-primary text-primary-foreground font-mono">Gatekeeper: PASS</Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-muted/50 rounded-lg p-4 border border-success/20">
          <p className="text-sm leading-relaxed text-foreground">
            After comprehensive multi-agent analysis and constitutional compliance verification, the synthesized
            response recommends implementing a robust multi-layered verification system. This approach integrates
            cryptographic attestation, circuit breaker patterns with exponential backoff, and semantic validation layers
            to ensure both security and operational efficiency.
          </p>
          <p className="text-sm leading-relaxed text-foreground mt-3">
            The consensus synthesis prioritizes trust engine validation before final output, incorporating outlier
            detection mechanisms with z-score thresholds calibrated to maintain response quality. All components have
            passed behavioral gatekeeper checks and comply with IECF constitutional standards, ensuring sovereign-grade
            intelligence delivery.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-4 pt-2">
          <div className="space-y-1">
            <p className="text-xs font-mono text-muted-foreground">Trust Score</p>
            <p className="text-lg font-mono text-success">0.95</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs font-mono text-muted-foreground">Synthesis Time</p>
            <p className="text-lg font-mono text-primary">4.2s</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs font-mono text-muted-foreground">Agents Consensus</p>
            <p className="text-lg font-mono text-foreground">3/3</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
