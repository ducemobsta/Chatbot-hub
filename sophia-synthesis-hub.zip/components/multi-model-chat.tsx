"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sidebar } from "@/components/sidebar"
import { ChatPanel } from "@/components/chat-panel"
import { ImageGenerator } from "@/components/image-generator"
import { WebSummarizer } from "@/components/web-summarizer"
import { SettingsDialog } from "@/components/settings-dialog"
import { PanelLeft, Plus, Send, Settings } from "lucide-react"
import { cn } from "@/lib/utils"

export type Model = {
  id: string
  name: string
  provider: string
  icon?: string
}

export type Message = {
  role: "user" | "assistant"
  content: string
  model?: string
}

export type ChatSession = {
  id: string
  model: Model
  messages: Message[]
  isLoading: boolean
}

const AVAILABLE_MODELS: Model[] = [
  { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash", provider: "google" },
  { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro", provider: "google" },
  { id: "gemini-2.0-flash-exp", name: "Gemini 2.0 Flash (Experimental)", provider: "google" },
]

export function MultiModelChat() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [currentView, setCurrentView] = useState<"chat" | "image-generator" | "web-summarizer">("chat")
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([
    { id: "1", model: AVAILABLE_MODELS[0], messages: [], isLoading: false },
    { id: "2", model: AVAILABLE_MODELS[1], messages: [], isLoading: false },
  ])
  const [input, setInput] = useState("")
  const [apiKeys, setApiKeys] = useState<{
    google?: string
    openai?: string
    anthropic?: string
  }>({})
  const [settingsOpen, setSettingsOpen] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem("apiKeys")
    if (stored) {
      setApiKeys(JSON.parse(stored))
    }
  }, [])

  const saveApiKeys = (keys: typeof apiKeys) => {
    setApiKeys(keys)
    localStorage.setItem("apiKeys", JSON.stringify(keys))
  }

  const addChatSession = (model: Model) => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      model,
      messages: [],
      isLoading: false,
    }
    setChatSessions([...chatSessions, newSession])
  }

  const removeChatSession = (id: string) => {
    setChatSessions(chatSessions.filter((session) => session.id !== id))
  }

  const changeModel = (sessionId: string, model: Model) => {
    setChatSessions(chatSessions.map((session) => (session.id === sessionId ? { ...session, model } : session)))
  }

  const sendMessage = async () => {
    if (!input.trim()) return

    if (!apiKeys.google) {
      alert("Please configure your Google API key in Settings before sending messages.")
      setSettingsOpen(true)
      return
    }

    const userMessage: Message = { role: "user", content: input }

    setChatSessions(
      chatSessions.map((session) => ({
        ...session,
        messages: [...session.messages, userMessage],
        isLoading: true,
      })),
    )

    setInput("")

    const promises = chatSessions.map(async (session) => {
      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [...session.messages, userMessage],
            model: session.model.id,
            apiKeys: apiKeys,
          }),
        })

        let data
        const contentType = response.headers.get("content-type")

        if (contentType?.includes("application/json")) {
          data = await response.json()
        } else {
          throw new Error(`Invalid response type: ${contentType}`)
        }

        if (!response.ok) {
          throw new Error(data.error || "Failed to get response")
        }

        return {
          sessionId: session.id,
          message: { role: "assistant" as const, content: data.content, model: session.model.name },
          error: null,
        }
      } catch (error: any) {
        return {
          sessionId: session.id,
          message: {
            role: "assistant" as const,
            content: `Error: ${error?.message || "Failed to get response"}`,
            model: session.model.name,
          },
          error: error?.message,
        }
      }
    })

    const results = await Promise.all(promises)

    setChatSessions((prev) =>
      prev.map((session) => {
        const result = results.find((r) => r.sessionId === session.id)
        if (result) {
          return {
            ...session,
            messages: [...session.messages, result.message],
            isLoading: false,
          }
        }
        return { ...session, isLoading: false }
      }),
    )
  }

  const retryMessage = async (sessionId: string, messageIndex: number) => {
    const session = chatSessions.find((s) => s.id === sessionId)
    if (!session) return

    const message = session.messages[messageIndex]
    if (message.role === "user") {
      // Retry sending user message
      setInput(message.content)
    } else {
      // Retry getting assistant response
      const previousUserMessage = session.messages
        .slice(0, messageIndex)
        .reverse()
        .find((m) => m.role === "user")

      if (previousUserMessage) {
        setChatSessions((prev) => prev.map((s) => (s.id === sessionId ? { ...s, isLoading: true } : s)))

        try {
          const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              messages: session.messages.slice(0, messageIndex),
              model: session.model.id,
              apiKeys: apiKeys,
            }),
          })

          const data = await response.json()

          setChatSessions((prev) =>
            prev.map((s) => {
              if (s.id === sessionId) {
                const newMessages = [...s.messages]
                newMessages[messageIndex] = {
                  role: "assistant",
                  content: data.content,
                  model: s.model.name,
                }
                return { ...s, messages: newMessages, isLoading: false }
              }
              return s
            }),
          )
        } catch (error) {
          setChatSessions((prev) => prev.map((s) => (s.id === sessionId ? { ...s, isLoading: false } : s)))
        }
      }
    }
  }

  const editMessage = (sessionId: string, messageIndex: number, newContent: string) => {
    setChatSessions((prev) =>
      prev.map((s) => {
        if (s.id === sessionId) {
          const newMessages = [...s.messages]
          newMessages[messageIndex] = { ...newMessages[messageIndex], content: newContent }
          return { ...s, messages: newMessages }
        }
        return s
      }),
    )
  }

  const deleteMessage = (sessionId: string, messageIndex: number) => {
    setChatSessions((prev) =>
      prev.map((s) => {
        if (s.id === sessionId) {
          return { ...s, messages: s.messages.filter((_, i) => i !== messageIndex) }
        }
        return s
      }),
    )
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <Sidebar
        open={sidebarOpen}
        models={AVAILABLE_MODELS}
        selectedModels={chatSessions.map((s) => s.model.id)}
        currentView={currentView}
        onModelSelect={addChatSession}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        onViewChange={setCurrentView}
      />

      {/* Main Content */}
      <div className="flex flex-1 flex-col">
        {/* Header */}
        <div className="flex h-14 items-center gap-2 border-b px-4">
          {!sidebarOpen && (
            <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(true)}>
              <PanelLeft className="h-5 w-5" />
            </Button>
          )}
          <div className="flex-1" />
          <Button variant="ghost" size="icon" onClick={() => setSettingsOpen(true)}>
            <Settings className="h-5 w-5" />
          </Button>
          {currentView === "chat" && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                if (chatSessions.length < 4) {
                  addChatSession(AVAILABLE_MODELS[chatSessions.length % AVAILABLE_MODELS.length])
                }
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Model
            </Button>
          )}
        </div>

        {currentView === "image-generator" ? (
          <ImageGenerator />
        ) : currentView === "web-summarizer" ? (
          <WebSummarizer />
        ) : (
          <>
            {/* Chat Panels */}
            <div className="flex flex-1 overflow-hidden">
              {chatSessions.length === 0 ? (
                <div className="flex flex-1 flex-col items-center justify-center gap-4 text-muted-foreground">
                  <p>Select a model from the sidebar to start chatting</p>
                  {!apiKeys.google && (
                    <Button variant="outline" onClick={() => setSettingsOpen(true)}>
                      <Settings className="mr-2 h-4 w-4" />
                      Configure Google API Key
                    </Button>
                  )}
                </div>
              ) : (
                <div
                  className={cn(
                    "grid flex-1 gap-2 p-2",
                    chatSessions.length === 1 && "grid-cols-1",
                    chatSessions.length === 2 && "grid-cols-2",
                    chatSessions.length === 3 && "grid-cols-3",
                    chatSessions.length >= 4 && "grid-cols-2 grid-rows-2",
                  )}
                >
                  {chatSessions.map((session) => (
                    <ChatPanel
                      key={session.id}
                      session={session}
                      availableModels={AVAILABLE_MODELS}
                      onRemove={() => removeChatSession(session.id)}
                      onChangeModel={(model) => changeModel(session.id, model)}
                      onRetryMessage={(index) => retryMessage(session.id, index)}
                      onEditMessage={(index, content) => editMessage(session.id, index, content)}
                      onDeleteMessage={(index) => deleteMessage(session.id, index)}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Input Area */}
            <div className="border-t p-4">
              <div className="mx-auto max-w-4xl">
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault()
                        sendMessage()
                      }
                    }}
                    placeholder="Type your message here..."
                    className="flex-1"
                  />
                  <Button onClick={sendMessage} disabled={!input.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <p className="mt-2 text-xs text-muted-foreground">Press Enter to send, Shift+Enter for new line</p>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Settings Dialog */}
      <SettingsDialog
        open={settingsOpen}
        onOpenChange={setSettingsOpen}
        apiKeys={apiKeys}
        onSaveApiKeys={saveApiKeys}
      />
    </div>
  )
}
