"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { ProtocolStepper } from "@/components/protocol-stepper"
import { AgentOutputs } from "@/components/agent-outputs"
import { FinalVerdict } from "@/components/final-verdict"
import { AuditHistory } from "@/components/audit-history"
import { Menu, X } from "lucide-react"

export function SophiaSynthesisHub() {
  const [query, setQuery] = useState("")
  const [isSynthesizing, setIsSynthesizing] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [showLeftSidebar, setShowLeftSidebar] = useState(true)
  const [showRightSidebar, setShowRightSidebar] = useState(true)
  const [synthesisComplete, setSynthesisComplete] = useState(false)

  const handleSynthesize = async () => {
    setIsSynthesizing(true)
    setSynthesisComplete(false)

    // Simulate protocol chain execution
    for (let i = 0; i <= 5; i++) {
      await new Promise((resolve) => setTimeout(resolve, 800))
      setCurrentStep(i)
    }

    setIsSynthesizing(false)
    setSynthesisComplete(true)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowLeftSidebar(!showLeftSidebar)}
              className="lg:hidden p-2 hover:bg-muted rounded-md"
            >
              {showLeftSidebar ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <div>
              <h1 className="text-xl font-bold font-mono text-primary">SOPHIA AI CORE</h1>
              <p className="text-xs text-muted-foreground font-mono">Response Synthesis & Governance Hub v3.2</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="font-mono text-xs border-success text-success">
              SOVEREIGN-GRADE
            </Badge>
            <button
              onClick={() => setShowRightSidebar(!showRightSidebar)}
              className="lg:hidden p-2 hover:bg-muted rounded-md"
            >
              {showRightSidebar ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Layout */}
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Sidebar - Protocol Chain */}
          <aside className={`lg:col-span-3 ${showLeftSidebar ? "block" : "hidden lg:block"}`}>
            <ProtocolStepper currentStep={currentStep} isSynthesizing={isSynthesizing} />
          </aside>

          {/* Center Column - Main Interaction */}
          <main className="lg:col-span-6 space-y-6">
            {/* Input Card */}
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="font-mono text-primary">Constitutional Query Input</CardTitle>
                <CardDescription className="font-mono text-xs">
                  Enter your query for multi-agent consensus synthesis
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Enter your query here..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="min-h-[120px] font-mono text-sm bg-muted/50"
                />
                <div className="flex items-center justify-between">
                  <Button
                    onClick={handleSynthesize}
                    disabled={!query.trim() || isSynthesizing}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground font-mono"
                  >
                    {isSynthesizing ? "Synthesizing..." : "Synthesize and Enforce Protocol"}
                  </Button>
                  <div className="flex items-center gap-2">
                    <div
                      className={`h-2 w-2 rounded-full ${isSynthesizing ? "bg-warning animate-pulse" : "bg-muted"}`}
                    />
                    <span className="text-xs font-mono text-muted-foreground">Behavioral Gatekeeper Watch</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Agent Outputs */}
            {currentStep >= 4 && <AgentOutputs />}

            {/* Final Verdict */}
            {synthesisComplete && <FinalVerdict query={query} />}
          </main>

          {/* Right Sidebar - Audit History */}
          <aside className={`lg:col-span-3 ${showRightSidebar ? "block" : "hidden lg:block"}`}>
            <AuditHistory />
          </aside>
        </div>
      </div>
    </div>
  )
}
