import { MultiModelChat } from "@/components/multi-model-chat"

export default function Home() {
  return <MultiModelChat />
}
