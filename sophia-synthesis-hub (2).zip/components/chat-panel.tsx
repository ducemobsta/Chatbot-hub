"use client"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { X, ChevronDown, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import type { ChatSession, Model } from "./multi-model-chat"
import { useEffect, useRef } from "react"

type ChatPanelProps = {
  session: ChatSession
  availableModels: Model[]
  onRemove: () => void
  onChangeModel: (model: Model) => void
}

export function ChatPanel({ session, availableModels, onRemove, onChangeModel }: ChatPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [session.messages])

  return (
    <div className="flex flex-col overflow-hidden rounded-lg border bg-card">
      {/* Header */}
      <div className="flex items-center justify-between border-b px-4 py-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="gap-2">
              <span className="font-medium">{session.model.name}</span>
              <ChevronDown className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            {availableModels.map((model) => (
              <DropdownMenuItem key={model.id} onClick={() => onChangeModel(model)}>
                {model.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        <Button variant="ghost" size="icon" onClick={onRemove}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4">
        {session.messages.length === 0 ? (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            Start a conversation with {session.model.name}
          </div>
        ) : (
          <div className="space-y-4">
            {session.messages.map((message, index) => (
              <div
                key={index}
                className={cn(
                  "rounded-lg p-3 text-sm",
                  message.role === "user"
                    ? "bg-primary text-primary-foreground ml-auto max-w-[85%]"
                    : "bg-muted mr-auto max-w-[85%]",
                )}
              >
                <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>
              </div>
            ))}
            {session.isLoading && (
              <div className="flex items-center gap-2 rounded-lg bg-muted p-3 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>{session.model.name} is thinking...</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
