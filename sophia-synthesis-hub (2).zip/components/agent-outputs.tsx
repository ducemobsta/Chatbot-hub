"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ChevronDown, ChevronUp, AlertTriangle } from "lucide-react"

const mockAgents = [
  {
    id: "alpha",
    name: "Agent Alpha",
    model: "GPT-4o",
    trustScore: 0.95,
    output:
      "Based on the constitutional framework, the optimal approach involves implementing a multi-layered verification system with cryptographic attestation at each stage. This ensures data integrity while maintaining operational efficiency.",
  },
  {
    id: "beta",
    name: "Agent Beta",
    model: "Claude-3.5 Haiku",
    trustScore: 0.92,
    output:
      "The constitutional requirements mandate a balanced approach between security and performance. Recommend implementing circuit breakers with exponential backoff and semantic validation layers to ensure compliance with IECF standards.",
  },
  {
    id: "gamma",
    name: "Agent Gamma",
    model: "Llama 3 (TIER1)",
    trustScore: 0.88,
    output:
      "Analysis suggests prioritizing trust engine validation before consensus synthesis. The fallback chain should include outlier detection with z-score thresholds above 0.3 to maintain response quality while ensuring resilience.",
  },
]

export function AgentOutputs() {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <Card className="border-warning/30">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <CardTitle className="font-mono text-sm">Raw Agent Outputs (Pre-Verification)</CardTitle>
              <Badge variant="outline" className="border-warning text-warning font-mono text-xs">
                <AlertTriangle className="h-3 w-3 mr-1" />
                UNVERIFIED DATA
              </Badge>
            </div>
            <CardDescription className="font-mono text-xs">
              Multi-agent responses before consensus synthesis
            </CardDescription>
          </div>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 hover:bg-muted rounded-md transition-colors"
          >
            {isExpanded ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
          </button>
        </div>
      </CardHeader>
      {isExpanded && (
        <CardContent>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {mockAgents.map((agent) => (
              <Card key={agent.id} className="flex-shrink-0 w-80 bg-muted/30 border-border">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="font-mono text-sm">{agent.name}</CardTitle>
                    <Badge variant="secondary" className="font-mono text-xs">
                      Trust: {agent.trustScore}
                    </Badge>
                  </div>
                  <CardDescription className="font-mono text-xs">{agent.model}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-muted-foreground leading-relaxed">{agent.output}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      )}
    </Card>
  )
}
