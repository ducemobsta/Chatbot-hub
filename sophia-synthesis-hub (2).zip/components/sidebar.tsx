"use client"

import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { PanelLeftClose, ImageIcon, Languages, FileText, Check } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Model } from "./multi-model-chat"

type SidebarProps = {
  open: boolean
  models: Model[]
  selectedModels: string[]
  onModelSelect: (model: Model) => void
  onToggle: () => void
}

export function Sidebar({ open, models, selectedModels, onModelSelect, onToggle }: SidebarProps) {
  if (!open) return null

  return (
    <div className="flex w-64 flex-col border-r bg-sidebar">
      {/* Header */}
      <div className="flex h-14 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <span className="text-sm font-bold text-primary-foreground">S</span>
          </div>
          <span className="font-semibold text-sidebar-foreground">Sophia AI</span>
        </div>
        <Button variant="ghost" size="icon" onClick={onToggle}>
          <PanelLeftClose className="h-5 w-5" />
        </Button>
      </div>

      <Separator />

      <ScrollArea className="flex-1">
        <div className="p-4">
          {/* All-In-One Section */}
          <div className="mb-4">
            <Button
              variant="secondary"
              className="w-full justify-start"
              onClick={() => {
                // Select first 2 models for all-in-one
                if (selectedModels.length === 0) {
                  onModelSelect(models[0])
                  onModelSelect(models[2])
                }
              }}
            >
              All-In-One
            </Button>
          </div>

          {/* Tools Section */}
          <div className="mb-6">
            <h3 className="mb-2 px-2 text-xs font-semibold text-muted-foreground">Tools</h3>
            <div className="space-y-1">
              <Button variant="ghost" className="w-full justify-start" disabled>
                <ImageIcon className="mr-2 h-4 w-4" />
                Image Generator
              </Button>
              <Button variant="ghost" className="w-full justify-start" disabled>
                <Languages className="mr-2 h-4 w-4" />
                AI Translator
              </Button>
              <Button variant="ghost" className="w-full justify-start" disabled>
                <FileText className="mr-2 h-4 w-4" />
                Web Summarizer
              </Button>
            </div>
          </div>

          {/* Models Section */}
          <div>
            <h3 className="mb-2 px-2 text-xs font-semibold text-muted-foreground">Models</h3>
            <div className="space-y-1">
              {models.map((model) => {
                const isSelected = selectedModels.includes(model.id)
                return (
                  <Button
                    key={model.id}
                    variant={isSelected ? "secondary" : "ghost"}
                    className={cn("w-full justify-start", isSelected && "bg-sidebar-accent")}
                    onClick={() => !isSelected && onModelSelect(model)}
                  >
                    <span className="flex-1 text-left">{model.name}</span>
                    {isSelected && <Check className="h-4 w-4" />}
                  </Button>
                )
              })}
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}
