import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText } from "lucide-react"

export function AuditHistory() {
  return (
    <Card className="sticky top-24">
      <CardHeader>
        <CardTitle className="font-mono text-sm text-muted-foreground">Audit History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <FileText className="h-12 w-12 text-muted-foreground/30 mb-3" />
          <p className="text-xs font-mono text-muted-foreground">No sessions recorded</p>
        </div>
      </CardContent>
    </Card>
  )
}
