"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Eye, EyeOff } from "lucide-react"

type ApiKeys = {
  google?: string
  openai?: string
  anthropic?: string
}

type SettingsDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  apiKeys: ApiKeys
  onSaveApiKeys: (keys: ApiKeys) => void
}

export function SettingsDialog({ open, onOpenChange, apiKeys, onSaveApiKeys }: SettingsDialogProps) {
  const [keys, setKeys] = useState<ApiKeys>(apiKeys)
  const [showKeys, setShowKeys] = useState({
    google: false,
    openai: false,
    anthropic: false,
  })

  const handleSave = () => {
    onSaveApiKeys(keys)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>
            Configure your API keys to use different AI models. Keys are stored locally in your browser.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="api-keys" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="api-keys">API Keys</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
          </TabsList>

          <TabsContent value="api-keys" className="space-y-4">
            <div className="space-y-4">
              {/* Google API Key */}
              <div className="space-y-2">
                <Label htmlFor="google-key">Google AI API Key</Label>
                <div className="flex gap-2">
                  <Input
                    id="google-key"
                    type={showKeys.google ? "text" : "password"}
                    placeholder="Enter your Google AI API key"
                    value={keys.google || ""}
                    onChange={(e) => setKeys({ ...keys, google: e.target.value })}
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setShowKeys({ ...showKeys, google: !showKeys.google })}
                  >
                    {showKeys.google ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Get your key from{" "}
                  <a
                    href="https://aistudio.google.com/app/apikey"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    Google AI Studio
                  </a>
                </p>
              </div>

              {/* OpenAI API Key */}
              <div className="space-y-2">
                <Label htmlFor="openai-key">OpenAI API Key</Label>
                <div className="flex gap-2">
                  <Input
                    id="openai-key"
                    type={showKeys.openai ? "text" : "password"}
                    placeholder="Enter your OpenAI API key"
                    value={keys.openai || ""}
                    onChange={(e) => setKeys({ ...keys, openai: e.target.value })}
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setShowKeys({ ...showKeys, openai: !showKeys.openai })}
                  >
                    {showKeys.openai ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Get your key from{" "}
                  <a
                    href="https://platform.openai.com/api-keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    OpenAI Platform
                  </a>
                </p>
              </div>

              {/* Anthropic API Key */}
              <div className="space-y-2">
                <Label htmlFor="anthropic-key">Anthropic API Key</Label>
                <div className="flex gap-2">
                  <Input
                    id="anthropic-key"
                    type={showKeys.anthropic ? "text" : "password"}
                    placeholder="Enter your Anthropic API key"
                    value={keys.anthropic || ""}
                    onChange={(e) => setKeys({ ...keys, anthropic: e.target.value })}
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setShowKeys({ ...showKeys, anthropic: !showKeys.anthropic })}
                  >
                    {showKeys.anthropic ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Get your key from{" "}
                  <a
                    href="https://console.anthropic.com/settings/keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    Anthropic Console
                  </a>
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave}>Save Keys</Button>
            </div>
          </TabsContent>

          <TabsContent value="about" className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-semibold">Multi-Model Chat</h3>
              <p className="text-sm text-muted-foreground">
                Compare responses from multiple AI models side-by-side. Your API keys are stored locally in your browser
                and never sent to any server except the respective AI providers.
              </p>
              <p className="text-sm text-muted-foreground mt-4">
                <strong>Currently supported:</strong> Google Gemini models (2.0 Flash, 1.5 Pro, 1.5 Flash)
              </p>
              <p className="text-sm text-muted-foreground">
                Add your Google API key to start chatting. Support for OpenAI and Anthropic models coming soon.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
