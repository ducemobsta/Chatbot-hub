import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, Loader2 } from "lucide-react"

interface ProtocolStepperProps {
  currentStep: number
  isSynthesizing: boolean
}

const steps = [
  { id: 1, name: "Data Ingestion: GEL Redaction", description: "Contamination check" },
  { id: 2, name: "Pact Schema Validation", description: "Input structure verification" },
  { id: 3, name: "Agent Identity & Trust Check", description: "Cryptographic signatures" },
  { id: 4, name: "Consensus Synthesis", description: "Weighted voting begins" },
  { id: 5, name: "Behavioral Gatekeeper Check", description: "Final IECF compliance" },
]

export function ProtocolStepper({ currentStep, isSynthesizing }: ProtocolStepperProps) {
  return (
    <Card className="sticky top-24">
      <CardHeader>
        <CardTitle className="font-mono text-sm text-primary">Mandatory Protocol Chain</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {steps.map((step, index) => {
            const isComplete = currentStep > step.id
            const isCurrent = currentStep === step.id && isSynthesizing
            const isPending = currentStep < step.id

            return (
              <div key={step.id} className="relative">
                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className={`absolute left-4 top-8 w-0.5 h-8 ${isComplete ? "bg-success" : "bg-border"}`} />
                )}

                {/* Step */}
                <div className="flex items-start gap-3">
                  {/* Status Icon */}
                  <div
                    className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border-2 ${
                      isComplete
                        ? "bg-success border-success"
                        : isCurrent
                          ? "bg-primary border-primary animate-pulse"
                          : "bg-muted border-border"
                    }`}
                  >
                    {isComplete ? (
                      <Check className="h-4 w-4 text-success-foreground" />
                    ) : isCurrent ? (
                      <Loader2 className="h-4 w-4 text-primary-foreground animate-spin" />
                    ) : (
                      <span className="text-xs font-mono text-muted-foreground">{step.id}</span>
                    )}
                  </div>

                  {/* Step Content */}
                  <div className="flex-1 pt-0.5">
                    <p
                      className={`text-sm font-mono leading-tight ${
                        isComplete || isCurrent ? "text-foreground" : "text-muted-foreground"
                      }`}
                    >
                      {step.name}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">{step.description}</p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
