async function fetchWithRetry(url: string, options: RequestInit, maxRetries = 2): Promise<Response> {
  for (let i = 0; i <= maxRetries; i++) {
    const response = await fetch(url, options)

    if (response.status === 503 && i < maxRetries) {
      const waitTime = Math.pow(2, i) * 1000
      await new Promise((resolve) => setTimeout(resolve, waitTime))
      continue
    }

    return response
  }

  throw new Error("Max retries exceeded")
}

export async function POST(req: Request) {
  try {
    const { messages, model, apiKeys } = await req.json()

    if (!apiKeys?.google) {
      return Response.json({ error: "Google API key required. Please add it in Settings." }, { status: 400 })
    }

    const googleModelId = model
    if (!["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash-exp"].includes(model)) {
      return Response.json(
        { error: `Model ${model} is not supported. Only Google Gemini models are currently available.` },
        { status: 400 },
      )
    }

    try {
      const lastMessage = messages[messages.length - 1]
      const directUrl = `https://generativelanguage.googleapis.com/v1beta/models/${googleModelId}:generateContent?key=${apiKeys.google}`

      const directResponse = await fetchWithRetry(directUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: lastMessage.content }],
            },
          ],
        }),
      })

      const directText = await directResponse.text()

      if (!directResponse.ok) {
        return Response.json({ error: `Google API error: ${directText}` }, { status: directResponse.status })
      }

      const directData = JSON.parse(directText)
      const responseText = directData.candidates?.[0]?.content?.parts?.[0]?.text || "No response"

      return Response.json({ content: responseText })
    } catch (directError: any) {
      throw directError
    }
  } catch (error: any) {
    return Response.json({ error: error?.message || "Failed to generate response" }, { status: 500 })
  }
}
